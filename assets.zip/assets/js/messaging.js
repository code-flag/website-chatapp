
		var flag = 0; var name ="name";var id = "";var reply = "";
					
		function refresh(n)
		{
			reply = "";
			if (n == 1) 
			{
			setInterval(function(){$(".message-line").load("chat-msg.php", {
							 message : "message",
							 reply: reply,
							 reciever_id: idGlobal
							 
						}); }, 5000);
			}
			else if (n == 1) 
			{
			setInterval(function(){$(".message-line").load("chat-msg.php", {
							 message : "message",
							 reply: reply,
							 reciever_id: idGlobal
							 
						}); }, 5000);
			}
			else{
				
			}
		}

		function trigEnter(event)
		{
			//get the keycode for all keyboard using x variable below
			//var x = event.keyCode;
			//$('#test-msg').val(x);
			if (event.keyCode == 13) {
				alert("it work");
			document.getElementById("message").click();
						}
		}

			

			$("#message").click(function(){
				reply = $('#test-msg').val();
				$('#test-msg').val("");
				$(".message-line").load("chat-msg.php", {
							 message : "message",
							 reply: reply
							 // reciever_id: idGlobal
						}); 
				//load friend info
				$("#friend-info").load("friend-info.php", {
							 message : "message",
							 reciever_id: idGlobal
						}); 

			});


			$("#refresh").click(function(){
				reply = "";
				$(".message-line").load("chat-msg.php", {
							message : "message",
							 reply: reply,
							 reciever_id: idGlobal
							 
						}); 
			});

			// open emoji panel to select icon
			$('.fa-meh-o').click(function(){
				var emoji = document.getElementById('overlay');
				//if user click other area aside icon maybe user dont want to select icon
				var tagetId =  document.getElementById('message-b');
				emoji.style.display = "block";

				window.onclick = function(event) {
			    if (event.target == tagetId) {
			        emoji.style.display = "none";
			    }
			}

				$("#overlay").on('click', function(){
					 emoji.style.display = "none";
					});
			});
			// get any selected emoji and add to the text in the text box
			$("#overlay a b ").on('click', function(){

				reply = $('#test-msg').val();
				// alert(this.id);
				reply = reply + this.id;
				document.getElementById('test-msg').value =reply;
				document.getElementById('overlay').style.display = "none";

				
		 	});



			//camera

			// Get the modal
var modal = document.getElementById('camera-modal');

// Get the button that opens the modal
var btn = document.getElementById("camera");

// Get the <span> element that closes the modal
var span = document.getElementById("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}


			// Get the modal
var modal2 = document.getElementById('pdf-modal');

// Get the button that opens the modal
var btn1 = document.getElementById("pdf");

// Get the <span> element that closes the modal
var span1 = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn1.onclick = function() {
    modal2.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span1.onclick = function() {
    modal2.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal2) {
        modal2.style.display = "none";
    }
}

	function inform()
	{

		document.getElementById("f-label").innerHTML = "file selected suceesfully"; 
		document.getElementById("f-submit").style.display ="block";
	}
	