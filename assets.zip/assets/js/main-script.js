
	    function phonecode()
	    {
	      document.getElementById("reg-phoneNo").value = "+234";
	    }
       // check the strength of password
  		function validate_password()

				 {
				 	var number = /([0-9])/;
					var alphabets = /([a-zA-Z])/;
					var special_character = /([`,!,@,#,$,%,*,&,^,-,=,+,>,_,<,?])/;

					if($('#reg-password1').val().length<6)
					{
						$('#pw-str-status').removeClass();
						$('#pw-str-status').addClass('weak_pw');
						$('#pw-str-status').html("weak (should be atleast 6 characters.)");
					}
					else
					{	
						if($('#reg-password1').val().match(number)  && $('#reg-password1').val().match(alphabets) && $('#reg-password1').val().match(special_character))
						{
							$('#pw-str-status').removeClass();
							$('#pw-str-status').addClass('strong_pw');
							$('#pw-str-status').html("strong");
						}
						else
						{
							$('#pw-str-status').removeClass();
							$('#pw-str-status').addClass('medium_pw');
							$('#pw-str-status').html(" medium (should include number alphabet and special charaters.)");
						}
					}
				 }
				 //validaye password match before posting to php
				 function passwordMatch()
				 {
				 	if ($('#reg-password1').val() != $('#reg-password2').val()) {
				 		$('#pw-str-status').removeClass();
						$('#pw-str-status').addClass('weak_pw');
						$('#pw-str-status').html("Password not match");
				 	}
				 	else
				 	{
				 		$('#pw-str-status').removeClass();
						$('#pw-str-status').html(" ");
				 	}
				 }

				 //validate password for retrieve password
				  function passwordMatch2()
				 {
				 	if ($('#r-password1').val() != $('#r-password2').val()) {
				 		$('#pw-status').removeClass();
						$('#pw-status').addClass('weak_pw');
						$('#pw-status').html("Password not match");
				 	}
				 	else
				 	{
				 		$('#pw-status').removeClass();
						$('#pw-status').html(" ");
				 	}
				 }


			function login()
			{
				var fd = new FormData();
				var username = $('#username').val();
				var password = $('#password').val();
				var submit = "submit";

				fd.append('username',username);
				fd.append('password',password);
                fd.append('submit', submit);


	                $.ajax({
	                    url:'login.php',
	                    type:'post',
	                    data:fd,
	                    contentType: false,
	                    processData: false,
	                    success:function(response){
	                        if(response != 0){
	                          // $(".image-preview").html(response);
	                           if(response == "done")
	                           {
	                           	window.location.href = 'profile.php';
	                           }
	                           else
	                           {
	                           		$('#error-message').html(response);
	                           }
	                        }
	                    }
	                });



			}
			function getpassword()
			{
				var fd = new FormData();

				var email = $('#r-email').val();
				var password = $('#r-password1').val();
				var passwordCode = $('#r-code').val();
				var submit = "submit";

				fd.append('email', email);
				fd.append('passwordCode', passwordCode);
                fd.append('password', password);
                fd.append('submit', submit);

	                $.ajax({
	                    url:'getpassword.php',
	                    type:'post',
	                    data:fd,
	                    contentType: false,
	                    processData: false,
	                    success:function(response){
	                        if(response != 0){
	                          // $(".image-preview").html(response);
	                           if(response == "done")
	                           {
	                           	window.location.href = 'sign-in.php';
	                           }
	                           else
	                           {
	                           		$('#error-msg').html(response);
	                           }
	                        }
	                    }
	                });
				
			}

			function register()
			{
				var files = $('#file')[0].files[0];
					
					var fd = new FormData();

					if($("#reg-sexm").prop('checked') == true && $("#reg-sexf").prop('checked') == true)
					{
						$('.sex').html("Only one gender type can be selected");
					}
					else if($("#reg-sexm").prop('checked') == true)
						{
							//var sex = $("#reg-sexm").is(":checked");
							var sex = "M";
						}
						else if($("#reg-sexf").prop('checked') == true)
						{
							var sex ="F";
						}
						else if($("#reg-sexm").prop('checked') == false && $("#reg-sexf").prop('checked') == false)
						{
							$('.sex').html("Please select your gender type");
						}

					if ($("#reg-password1").val() != $("#reg-password2").val() && $("#reg-fname").val() == "" && $("#reg-lname").val() == "" &&  $("#reg-email").val() == "" && $("#reg-phoneNo").val() == "")
					{
					 	alert("fill all the input field!"); 
					}
					else if ($("#reg-fname").val() == "")
					{
					 	$(".fname").html("* firstname is require") ;
					}
					else if ( $("#reg-lname").val() == "")
					{
					 	$(".lname").html("* lastname is require") ;
					}
					else if ( $("#reg-email").val() == "" )
					{
					 	$(".email").html("* Email is require") ;
					}
					else if ( $("#reg-phoneNo").val() == "")
					{
					 	$(".phoneNo").html("* Phone number is require") ;
					}
					else if ($("#reg-password1").val() != $("#reg-password2").val())
					{
					 	passwordMatch();
					}
					else if ($("#age").val())
					{
					 	$(".age").html("* Please don't forget your age") ;
					}
					else if(!files){
					 $(".image").html("* You must upload a file") ;
					}
	               
	                else{


	                var firstname = $("#reg-fname").val();
					var lastname = $("#reg-lname").val();
					var email = $("#reg-email").val();
					var tel = $("#reg-phoneNo").val();
					var password1 = $("#reg-password1").val();
					var password = $("#reg-password2").val();
					var age = $("#reg-age").val();
					var mstatus = $("#reg-mstatus").val();
					var religion = $("#reg-religion").val();
					var submit  = $("#reg-submit").val();


                	fd.append('email',email);
                	fd.append('fname', firstname);
                	fd.append('lname', lastname);
                	fd.append('phoneNo', tel);
                	fd.append('password', password);
                	fd.append('age', age);
                	fd.append('sex', sex);
                	fd.append('mstatus', mstatus);
                	fd.append('religion', religion);
                	fd.append('submit', submit);
	                fd.append('file',files);


	                $.ajax({
	                    url:'reg.php',
	                    type:'post',
	                    data:fd,
	                    contentType: false,
	                    processData: false,
	                    success:function(response){
	                        if(response != 0){
	                          // $(".image-preview").html(response);
	                           if(response == "done")
	                           {
	                           	window.location.href = 'profile.php';
	                           }
	                           else
	                           {
	                           		$('.form-message').html(response);
	                           }
	                        }else{
	                            alert('File not uploaded');
	                        }
	                    }
	                });
	            }
			}

			$(document).ready(function(){
				 //$("#reg-image").hide();
				 $('#r-email').show();
				 $('#r-email-icon').show();
				 $("#r-password").hide();
				  $("#r-password1").hide();
				  $("#r-password-icon").hide();
				  $("#r-password1-icon").hide();
				   $("#r-code").hide();
				  
				//EXECUTE REGISTER FORM
				 $(".form").submit(function(event){

					event.preventDefault();
					register();
				});

				 //EXECUTE LOGIN FORM
				 $(".login").submit(function(event){

					event.preventDefault();
					login();
				});

				 //EXECUTE PASSWORD RETRIEVING FROM

				 $(".retrieve_pw").submit(function(event){

				 		event.preventDefault();
					getpassword();
				 	$('#r-email').hide();
				 	$('#r-email-icon').hide();
				 	$('#r-password').show();
				 	 $("#r-password1").show();
				 	 $("#r-password-icon").show();
				  	$("#r-password1-icon").show();
				  	$("#r-code").show();
				  
				
				});
	
			});
		